export enum Role {
  STUDENT = 'student',
  ADMIN = 'admin',
}

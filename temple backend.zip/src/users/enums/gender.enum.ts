export enum Gender {
  MALE = 'male',
  FAMALE = 'female',
}

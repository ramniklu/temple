export class CreateProgramDto {
    name: string;

    code: string;
}
